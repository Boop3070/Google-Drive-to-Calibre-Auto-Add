import os
import threading
import queue
from datetime import datetime

from calibre.gui2.actions import InterfaceAction
from qt.core import QTimer
from calibre.ebooks.metadata.book.base import Metadata
from calibre.library import db

EBOOK_EXTENSIONS = {'.epub', '.mobi', '.pdf', '.azw', '.azw3', '.cbz', '.cbr', '.fb2'}


class GDriveWatcherAction(InterfaceAction):
    name        = 'GDrive Watcher'
    action_spec = ('GDrive Watcher', None, 'Watch Google Drive for new ebooks', None)
    popup_type  = 0

    def genesis(self):
        self.qaction.triggered.connect(self.show_log)
        self._log_entries    = []
        self._book_queue     = queue.Queue()
        self._stop_event     = threading.Event()
        self._watcher_thread = None

        self._timer = QTimer()
        self._timer.timeout.connect(self._process_book_queue)
        self._timer.start(2000)

    def initialization_complete(self):
        self._start_watcher()

    def shutting_down(self):
        self._stop_event.set()
        self._timer.stop()
        return True

    def _prefs(self):
        from calibre_plugins.gdrive_watcher.config import prefs
        return prefs

    def _log(self, msg):
        entry = f"[{datetime.now().strftime('%H:%M:%S')}]  {msg}"
        self._log_entries.append(entry)
        print(f'GDrive Watcher: {entry}')

    def _load_processed(self):
        return set(self._prefs()['processed_files'])

    def _save_processed(self, processed):
        self._prefs()['processed_files'] = sorted(processed)

    def _start_watcher(self):
        if self._watcher_thread and self._watcher_thread.is_alive():
            self._stop_event.set()
            self._watcher_thread.join(timeout=5)
        self._stop_event = threading.Event()
        self._watcher_thread = threading.Thread(
            target=self._watch_loop, daemon=True
        )
        self._watcher_thread.start()
        self._log('Watcher started.')

    def _watch_loop(self):
        gdrive = self._prefs()['gdrive_folder']

        if not gdrive or not os.path.isdir(gdrive):
            self._log(
                'GDrive folder not set or does not exist. '
                'Go to Settings on the bottom -> Folder to watch'
                'Alternative: Preferences > Plugins > GDrive Watcher > Customize.'
            )
            return

        processed = self._load_processed()

        if not processed:
            self._log('First run — seeding existing files (nothing will be added)...')
            count = 0
            for root, _dirs, files in os.walk(gdrive):
                for fname in files:
                    if os.path.splitext(fname)[1].lower() in EBOOK_EXTENSIONS:
                        rel = os.path.relpath(os.path.join(root, fname), gdrive)
                        processed.add(rel)
                        count += 1
            self._save_processed(processed)
            self._log(f'Seeded {count} file(s). Watching for new books only.')

        self._log(f'Polling every {self._prefs()["poll_interval"]}s.')

        while not self._stop_event.is_set():
            gdrive = self._prefs()['gdrive_folder']
            if gdrive and os.path.isdir(gdrive):
                self._scan(gdrive, processed)
            self._stop_event.wait(self._prefs()['poll_interval'])

    def _scan(self, gdrive, processed):
        newly_found = []
        for root, _dirs, files in os.walk(gdrive):
            for fname in files:
                if self._stop_event.is_set():
                    return
                if os.path.splitext(fname)[1].lower() not in EBOOK_EXTENSIONS:
                    continue
                fpath = os.path.join(root, fname)
                rel   = os.path.relpath(fpath, gdrive)
                if rel not in processed:
                    processed.add(rel)
                    newly_found.append((fpath, fname))

        if newly_found:
            self._save_processed(processed)
            for fpath, fname in newly_found:
                self._log(f'New book found: {fname}')
                self._book_queue.put(fpath)

    def _process_book_queue(self):
        if self._book_queue.empty():
            return
        added_ids = []
        while not self._book_queue.empty():
            try:
                fpath = self._book_queue.get_nowait()
                book_id = self._add_book_to_library(fpath)
                if book_id is not None:
                    added_ids.append(book_id)
            except queue.Empty:
                break

        if added_ids:
            self.gui.library_view.model().books_added(len(added_ids))
            self.gui.library_view.model().refresh()
            self.gui.tags_view.recount()
            self._log(f'Added {len(added_ids)} book(s) to library.')

    def _add_book_to_library(self, fpath):
        try:
            from calibre.ebooks.metadata.meta import get_metadata
            from calibre.ebooks.metadata.book.base import Metadata

            ext = os.path.splitext(fpath)[1][1:].lower()
            fmt = ext.upper()

            try:
                with open(fpath, 'rb') as f:
                    mi = get_metadata(f, stream_type=ext)
                self._log(f'Metadata read OK for {os.path.basename(fpath)}: "{mi.title}"')
            except Exception as e:
                self._log(f'Metadata read failed for {os.path.basename(fpath)}, using filename: {e}')
                mi = Metadata(os.path.splitext(os.path.basename(fpath))[0])

            db = self.gui.current_db.new_api
            ids, duplicates = db.add_books(
                [fpath],
                [fmt],
                [mi],
                add_duplicates=False,
                return_ids=True,
            )

            if ids:
                self._log(f'DB add OK: {os.path.basename(fpath)} -> id {ids[0]}')
                return ids[0]
            elif duplicates:
                self._log(f'Skipped duplicate: {os.path.basename(fpath)}')
                return None
            else:
                self._log(f'DB add returned no id and no duplicate for {os.path.basename(fpath)}')
                return None

        except Exception as e:
            self._log(f'Exception adding {os.path.basename(fpath)}: {e}')
            return None

    def show_log(self):
        from calibre_plugins.gdrive_watcher.ui import LogDialog
        dlg = LogDialog(self._log_entries, self._start_watcher, self.gui, self)
        dlg.exec()
