from calibre.customize import InterfaceActionBase


class GDriveWatcherPlugin(InterfaceActionBase):
    name                    = 'GDrive Watcher'
    description             = 'Watches a Google Drive folder and automatically adds new ebooks to your Calibre library'
    supported_platforms     = ['windows', 'osx', 'linux']
    author                  = 'User'
    version                 = (1, 0, 0)
    minimum_calibre_version = (5, 0, 0)
    actual_plugin           = 'calibre_plugins.gdrive_watcher.action:GDriveWatcherAction'

    def is_customizable(self):
        return True

    def config_widget(self):
        from calibre_plugins.gdrive_watcher.config import ConfigWidget
        return ConfigWidget()

    def save_settings(self, config_widget):
        config_widget.commit()
