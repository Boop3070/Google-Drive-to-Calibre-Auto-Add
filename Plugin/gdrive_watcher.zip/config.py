from calibre.utils.config import JSONConfig
from qt.core import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QSpinBox, QFileDialog
)

prefs = JSONConfig('plugins/gdrive_watcher')
prefs.defaults['gdrive_folder']   = ''
prefs.defaults['poll_interval']   = 60
prefs.defaults['processed_files'] = []


class ConfigWidget(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 20, 20, 20)

        layout.addWidget(QLabel('<b>Google Drive folder to watch:</b>'))

        gdrive_row = QHBoxLayout()
        self.gdrive_edit = QLineEdit(prefs['gdrive_folder'])
        self.gdrive_edit.setPlaceholderText('Select the synced Google Drive folder...')
        gdrive_row.addWidget(self.gdrive_edit)
        browse_btn = QPushButton('Browse...')
        browse_btn.clicked.connect(self._browse_gdrive)
        gdrive_row.addWidget(browse_btn)
        layout.addLayout(gdrive_row)

        layout.addSpacing(8)

        layout.addWidget(QLabel('<b>Poll interval</b> — how often to check for new books:'))
        interval_row = QHBoxLayout()
        self.poll_spin = QSpinBox()
        self.poll_spin.setRange(10, 3600)
        self.poll_spin.setSuffix(' seconds')
        self.poll_spin.setValue(prefs['poll_interval'])
        interval_row.addWidget(self.poll_spin)
        interval_row.addStretch()
        layout.addLayout(interval_row)

        layout.addSpacing(8)

        layout.addWidget(QLabel(
            'Clearing the processed list will cause the next poll to re-evaluate '
            'all files in the GDrive folder against your library.'
        ))
        reset_btn = QPushButton('Reset processed files list')
        reset_btn.clicked.connect(self._reset_processed)
        layout.addWidget(reset_btn)

        layout.addStretch()

    def _browse_gdrive(self):
        folder = QFileDialog.getExistingDirectory(
            self, 'Select Google Drive Folder', self.gdrive_edit.text()
        )
        if folder:
            self.gdrive_edit.setText(folder)

    def _reset_processed(self):
        prefs['processed_files'] = []
        from calibre.gui2 import info_dialog
        info_dialog(self, 'Done', 'Processed files list cleared.', show=True)

    def commit(self):
        prefs['gdrive_folder'] = self.gdrive_edit.text().strip()
        prefs['poll_interval'] = self.poll_spin.value()
