from qt.core import (
    QDialog, QVBoxLayout, QHBoxLayout, QTextEdit,
    QPushButton, QDialogButtonBox, QLabel, Qt, QFont, QTimer
)


class LogDialog(QDialog):
    def __init__(self, log_entries, restart_callback, gui, action):
        super().__init__(gui)
        self.setWindowTitle('GDrive Watcher — Activity Log')
        self.resize(640, 420)
        self._restart_callback = restart_callback
        self._log_entries      = log_entries
        self._last_seen        = 0
        self.action            = action
        self._setup_ui()
        self._flush()

        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._flush)
        self._poll_timer.start(500)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(16, 16, 16, 16)

        header = QLabel('<b>GDrive Watcher</b> — Activity Log')
        layout.addWidget(header)

        self.text = QTextEdit()
        self.text.setReadOnly(True)
        font = QFont('Consolas', 9)
        self.text.setFont(font)
        layout.addWidget(self.text)

        btn_row = QHBoxLayout()

        settings_btn = QPushButton('Settings…')
        settings_btn.setToolTip('Open plugin configuration')
        settings_btn.clicked.connect(self._open_settings)
        btn_row.addWidget(settings_btn)

        restart_btn = QPushButton('Restart Watcher')
        restart_btn.setToolTip('Stop and restart the watcher with current settings')
        restart_btn.clicked.connect(self._on_restart)
        btn_row.addWidget(restart_btn)

        clear_btn = QPushButton('Clear Log')
        clear_btn.clicked.connect(self._on_clear)
        btn_row.addWidget(clear_btn)

        btn_row.addStretch()

        close_btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close_btns.rejected.connect(self.reject)
        btn_row.addWidget(close_btns)

        layout.addLayout(btn_row)

    def _flush(self):
        current_len = len(self._log_entries)
        if current_len > self._last_seen:
            new_entries = self._log_entries[self._last_seen:current_len]
            self.text.append('\n'.join(new_entries))
            self.text.verticalScrollBar().setValue(
                self.text.verticalScrollBar().maximum()
            )
            self._last_seen = current_len

    def _open_settings(self):
        from calibre_plugins.gdrive_watcher.config import ConfigWidget

        dlg = QDialog(self)
        dlg.setWindowTitle('GDrive Watcher Settings')
        layout = QVBoxLayout(dlg)

        self._settings_widget = ConfigWidget()
        layout.addWidget(self._settings_widget)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(lambda: self._save_settings(dlg))
        buttons.rejected.connect(dlg.reject)
        layout.addWidget(buttons)

        dlg.exec()

    def _save_settings(self, dlg):
        self._settings_widget.commit()
        dlg.accept()

    def _on_restart(self):
        self._restart_callback()

    def _on_clear(self):
        self.text.clear()
        self._last_seen = len(self._log_entries)

    def reject(self):
        self._poll_timer.stop()
        super().reject()