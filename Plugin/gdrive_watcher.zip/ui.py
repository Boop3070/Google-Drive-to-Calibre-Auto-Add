from qt.core import (
    QDialog, QVBoxLayout, QHBoxLayout, QTextEdit,
    QPushButton, QDialogButtonBox, QLabel, Qt, QFont
)


class LogDialog(QDialog):
    def __init__(self, log_entries, restart_callback, gui, action):
        super().__init__(gui)
        self.setWindowTitle('GDrive Watcher — Activity Log')
        self.resize(640, 420)
        self._restart_callback = restart_callback
        self.action = action
        self._setup_ui(log_entries)

    def _setup_ui(self, log_entries):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(16, 16, 16, 16)

        header = QLabel('<b>GDrive Watcher</b> — Activity Log')
        layout.addWidget(header)

        self.text = QTextEdit()
        self.text.setReadOnly(True)
        font = QFont('Consolas', 9)
        self.text.setFont(font)
        self.text.setPlainText(
            '\n'.join(log_entries) if log_entries else 'No activity yet.'
        )
        self.text.verticalScrollBar().setValue(
            self.text.verticalScrollBar().maximum()
        )
        layout.addWidget(self.text)

        btn_row = QHBoxLayout()

        settings_btn = QPushButton('Settings…')
        settings_btn.setToolTip('Open plugin configuration')
        settings_btn.clicked.connect(self._open_settings)
        btn_row.addWidget(settings_btn)

        restart_btn = QPushButton('Restart Watcher')
        restart_btn.setToolTip('Stop and restart the watcher with current settings')
        restart_btn.clicked.connect(self._on_restart)
        btn_row.addWidget(restart_btn)

        clear_btn = QPushButton('Clear Log')
        clear_btn.clicked.connect(self._on_clear)
        btn_row.addWidget(clear_btn)

        btn_row.addStretch()

        close_btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close_btns.rejected.connect(self.reject)
        btn_row.addWidget(close_btns)

        layout.addLayout(btn_row)

    def _open_settings(self):
        from calibre_plugins.gdrive_watcher.config import ConfigWidget

        dlg = QDialog(self)
        dlg.setWindowTitle('GDrive Watcher Settings')
        layout = QVBoxLayout(dlg)

        self._settings_widget = ConfigWidget()
        layout.addWidget(self._settings_widget)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(lambda: self._save_settings(dlg))
        buttons.rejected.connect(dlg.reject)
        layout.addWidget(buttons)

        dlg.exec()

    def _save_settings(self, dlg):
        self._settings_widget.commit()
        dlg.accept()

    def _on_restart(self):
        self._restart_callback()
        self.text.append('\n[Watcher restarted]')

    def _on_clear(self):
        self.text.clear()